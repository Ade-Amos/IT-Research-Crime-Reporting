// server/routes/evidence.js
const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const auth = require('../middleware/auth');
const Evidence = require('../models/Evidence');

// ───── Multer config ─────
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/'),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const name = `${Date.now()}-${Math.round(Math.random() * 1E9)}${ext}`;
    cb(null, name);
  },
});

const fileFilter = (req, file, cb) => {
  const allowed = [
    'image/jpeg',
    'image/png',
    'image/gif',
    'image/webp',
    'application/pdf',
    'video/mp4',
    'video/webm',
    'audio/mpeg',
    'audio/wav',
  ];
  if (allowed.includes(file.mimetype)) cb(null, true);
  else cb(new Error('Invalid file type'), false);
};

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10 MB
  fileFilter,
});

// ───── UPLOAD ENDPOINT (global or per-case) ─────
router.post('/upload', auth, (req, res, next) => {
  upload.single('file')(req, res, async (err) => {
    // ── Multer errors → 400 ──
    if (err instanceof multer.MulterError) {
      if (err.code === 'LIMIT_FILE_SIZE')
        return res.status(400).json({ msg: 'File too large (max 10 MB)' });
      return res.status(400).json({ msg: err.message });
    }
    if (err) return res.status(400).json({ msg: err.message });

    // ── No file → 400 ──
    if (!req.file) return res.status(400).json({ msg: 'No file uploaded' });

    try {
      const { caseId, statementId, description } = req.body;

      // caseId is **optional** now (global upload allowed)
      const evidence = new Evidence({
        case: caseId || null,
        statement: statementId || null,
        filename: req.file.filename,
        originalName: req.file.originalname,
        mimetype: req.file.mimetype,
        size: req.file.size,
        description: description || '',
        uploadedBy: req.user.id,
      });

      await evidence.save();
      await evidence.populate('uploadedBy', 'name email');
      if (caseId) await evidence.populate('case', '_id');

      res.status(201).json(evidence);
    } catch (dbErr) {
      console.error('DB error on evidence upload:', dbErr);
      res.status(500).json({ msg: 'Server error' });
    }
  });
});

// ───── GET ALL EVIDENCE (global + filters + pagination) ─────
router.get('/', auth, async (req, res) => {
  try {
    const {
      case: caseId,
      statement: statementId,
      search,
      page = 1,
      limit = 12,
    } = req.query;

    const query = {};

    // Optional filters
    if (caseId) query.case = caseId;
    if (statementId) query.statement = statementId;
    if (search) {
      query.$or = [
        { originalName: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
      ];
    }

    const total = await Evidence.countDocuments(query);
    const evidence = await Evidence.find(query)
      .populate('uploadedBy', 'name email')
      .populate('case', '_id')
      .sort({ createdAt: -1 })
      .skip((parseInt(page) - 1) * parseInt(limit))
      .limit(parseInt(limit));

    const pages = Math.ceil(total / limit);

    res.json({
      evidence,
      pagination: {
        current: parseInt(page),
        pages,
        total,
        hasNext: page < pages,
        hasPrev: page > 1,
      },
    });
  } catch (err) {
    console.error('GET /evidence error:', err);
    res.status(500).json({ msg: 'Failed to fetch evidence' });
  }
});

// ───── DELETE EVIDENCE ─────
router.delete('/:id', auth, async (req, res) => {
  try {
    const evidence = await Evidence.findById(req.params.id);
    if (!evidence) return res.status(404).json({ msg: 'Evidence not found' });

    // Only admin or uploader can delete
    if (req.user.role !== 'admin' && evidence.uploadedBy.toString() !== req.user.id) {
      return res.status(403).json({ msg: 'Not authorized' });
    }

    // Optional: delete file from disk
    const fs = require('fs');
    const filePath = path.join(__dirname, '..', 'uploads', evidence.filename);
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);

    await evidence.deleteOne();
    res.json({ msg: 'Evidence deleted' });
  } catch (err) {
    console.error('DELETE /evidence error:', err);
    res.status(500).json({ msg: 'Server error' });
  }
});

module.exports = router;