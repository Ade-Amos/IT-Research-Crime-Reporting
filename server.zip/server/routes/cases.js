// server/routes/cases.js
const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Case = require('../models/Case');
const User = require('../models/User');

// === PAGINATION + SEARCH + FILTER + SORT ===
const paginate = (model) => async (req, res, next) => {
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 10;
  const search = req.query.search || '';
  const status = req.query.status || '';
  const sortBy = req.query.sortBy || 'createdAt';
  const sortOrder = req.query.sortOrder === 'asc' ? 1 : -1;
  const skip = (page - 1) * limit;

  try {
    const query = {};

    if (search) {
      query.$or = [
        { title: { $regex: search, $options: 'i' } },
        { type: { $regex: search, $options: 'i' } },
        { reportedByName: { $regex: search, $options: 'i' } }
      ];
    }

    if (status && ['open', 'pending', 'closed'].includes(status)) {
      query.status = status;
    }

    const total = await model.countDocuments(query);

    const sortOptions = {};
    if (sortBy === '_id') sortOptions._id = sortOrder;
    else if (sortBy === 'assignedTo') sortOptions['assignedTo.name'] = sortOrder;
    else sortOptions[sortBy] = sortOrder;

    const cases = await model.find(query)
      .populate('assignedTo', 'name email')
      .sort(sortOptions)
      .skip(skip)
      .limit(limit);

    res.json({
      cases,
      pagination: {
        current: page,
        pages: Math.ceil(total / limit),
        total,
        hasNext: page < Math.ceil(total / limit),
        hasPrev: page > 1
      }
    });
  } catch (err) {
    console.error('Pagination error:', err);
    next(err);
  }
};

// GET all cases
router.get('/', auth, paginate(Case));

// GET officers (Admin only)
router.get('/officers', auth, async (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ msg: 'Access denied' });
  }
  try {
    const officers = await User.find({ role: 'officer' }).select('name email _id');
    res.json(officers);
  } catch (err) {
    res.status(500).json({ msg: 'Failed to fetch officers' });
  }
});

/* ================================================================
   CREATE CASE – OFFICERS + ADMINS
   → No auto-assignment
   → Only admin can assign during creation
   → No officerInCharge field used
   ================================================================ */
router.post('/', auth, async (req, res) => {
  const {
    title,
    type,
    description,
    location,
    reportedByName,
    assignedTo        // Only respected if user is admin
  } = req.body;

  try {
    if (!title?.trim()) return res.status(400).json({ msg: 'Case title is required' });
    if (!type?.trim()) return res.status(400).json({ msg: 'Crime type is required' });

    const caseData = {
      title: title.trim(),
      type: type.trim(),
      description: description?.trim() || '',
      reportedByName: reportedByName?.trim() || '',
      status: 'open',
      assignedTo: null  // Start unassigned
    };

    // Handle location
    if (location?.lat != null && location?.lng != null) {
      const lat = parseFloat(location.lat);
      const lng = parseFloat(location.lng);
      if (isNaN(lat) || isNaN(lng)) {
        return res.status(400).json({ msg: 'Invalid coordinates' });
      }
      caseData.location = {
        type: 'Point',
        coordinates: [lng, lat]  // GeoJSON: [lng, lat]
      };
    }

    // Only admins can assign an officer during case creation
    if (req.user.role === 'admin' && assignedTo) {
      caseData.assignedTo = assignedTo;
    }
    // Officers → case remains unassigned

    const newCase = new Case(caseData);
    await newCase.save();
    await newCase.populate('assignedTo', 'name email');

    res.status(201).json(newCase);
  } catch (err) {
    console.error('Create case error:', err);
    res.status(500).json({
      msg: process.env.NODE_ENV === 'development'
        ? err.message
        : 'Failed to create case'
    });
  }
});

/* ================================================================
   UPDATE STATUS – Admin Only
   ================================================================ */
router.patch('/:id/status', auth, async (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ msg: 'Only admins can change case status' });
  }

  const { status } = req.body;
  if (!['open', 'pending', 'closed'].includes(status)) {
    return res.status(400).json({ msg: 'Invalid status' });
  }

  try {
    const updatedCase = await Case.findByIdAndUpdate(
      req.params.id,
      { status, updatedAt: Date.now() },
      { new: true }
    ).populate('assignedTo', 'name email');

    if (!updatedCase) return res.status(404).json({ msg: 'Case not found' });
    res.json(updatedCase);
  } catch (err) {
    res.status(500).json({ msg: 'Status update failed' });
  }
});

/* ================================================================
   ASSIGN OFFICER – Admin Only
   ================================================================ */
router.patch('/:id/assign', auth, async (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ msg: 'Only admins can assign officers' });
  }

  const { officerId } = req.body;
  if (!officerId) return res.status(400).json({ msg: 'Officer ID required' });

  try {
    const updatedCase = await Case.findByIdAndUpdate(
      req.params.id,
      { assignedTo: officerId, updatedAt: Date.now() },
      { new: true }
    ).populate('assignedTo', 'name email');

    if (!updatedCase) return res.status(404).json({ msg: 'Case not found' });
    res.json(updatedCase);
  } catch (err) {
    res.status(500).json({ msg: 'Assignment failed' });
  }
});

/* ================================================================
   GET CASE TIMELINE
   ================================================================ */
router.get('/:id/timeline', auth, async (req, res) => {
  try {
    const c = await Case.findById(req.params.id).populate('assignedTo', 'name');
    if (!c) return res.status(404).json({ msg: 'Case not found' });

    const Statement = require('../models/Statement');
    const statements = await Statement.find({ caseId: req.params.id })
      .populate('author', 'name')
      .sort({ createdAt: 1 });

    const timeline = [
      {
        title: 'Case Reported',
        actor: c.reportedByName || 'Citizen',
        description: c.title,
        timestamp: c.createdAt
      },
      ...statements.map(s => ({
        title: 'Statement Added',
        actor: s.author?.name || 'Officer',
        description: s.narrative?.substring(0, 100) + '...',
        timestamp: s.createdAt
      })),
      c.assignedTo && {
        title: 'Officer Assigned',
        actor: c.assignedTo.name,
        description: 'Case assigned',
        timestamp: c.updatedAt || c.createdAt
      },
      {
        title: 'Status Updated',
        actor: 'Admin',
        description: `Status: ${c.status.toUpperCase()}`,
        timestamp: c.updatedAt || c.createdAt
      }
    ].filter(Boolean);

    res.json({ case: c, timeline });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Failed to load timeline' });
  }
});

module.exports = router;