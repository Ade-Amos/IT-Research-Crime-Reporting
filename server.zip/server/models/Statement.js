// models/Statement.js
const mongoose = require('mongoose');

const statementSchema = new mongoose.Schema({
  caseId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Case',
    required: true
  },
  personName: {
    type: String,
    required: true,
    trim: true
  },
  type: {
    type: String,
    enum: ['witness', 'officer', 'complainant', 'suspect'],
    default: 'witness'
  },
  officer: {
    type: String,
    trim: true
  },
  narrative: {
    type: String,
    required: true,
    trim: true
  },
  status: {
    type: String,
    enum: ['pending', 'reviewed', 'verified'],
    default: 'pending'
  },
  author: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  files: [{
    name: String,
    path: String,
    url: String
  }]
}, {
  timestamps: true  // auto adds createdAt & updatedAt
});

module.exports = mongoose.model('Statement', statementSchema);