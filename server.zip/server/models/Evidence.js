// server/models/Evidence.js
const mongoose = require('mongoose');

const evidenceSchema = new mongoose.Schema({
  case: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Case',
    required: false,        // ← NOW OPTIONAL (global evidence allowed)
    index: true,            // fast queries by case
    default: null,
  },
  statement: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Statement',
    required: false,
    index: true,
    default: null,
  },
  filename: {
    type: String,
    required: true,
    trim: true,
  },
  originalName: {
    type: String,
    required: true,
    trim: true,
  },
  mimetype: {
    type: String,
    required: true,
    trim: true,
  },
  size: {
    type: Number,
    required: true,
    min: 0,
  },
  description: {
    type: String,
    trim: true,
    default: '',
  },
  uploadedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
    index: true, // fast sorting by date
  },
});

// ───── Virtual: Public URL ─────
evidenceSchema.virtual('url').get(function () {
  return `/uploads/${this.filename}`;
});

// ───── Ensure virtuals in JSON ─────
evidenceSchema.set('toJSON', { virtuals: true });
evidenceSchema.set('toObject', { virtuals: true });

// ───── Compound index for common filters ─────
evidenceSchema.index({ case: 1, statement: 1 });
evidenceSchema.index({ uploadedBy: 1, createdAt: -1 });

module.exports = mongoose.model('Evidence', evidenceSchema);